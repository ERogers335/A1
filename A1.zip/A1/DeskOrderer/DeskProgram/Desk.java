
/**
 * DeskProgram is a program for carpenters to present to their clients
 * so they can order desks.
 *
 * @author Evan Rogers
 * @version 1.0
 */
public class Desk
{
    // instance variables - replace the example below with your own
    private int flatRate;
    private int total;
    private int surface;
    private int numOfDrawers;
    private int drawerCharge;
    private int woodCharge;
    private int woodType;
    private int orderNumber;
    private String name;

    /**
     * Constructor for objects of class Desk
     */
    public Desk(int length, int width, int numberOfDrawers, int typeOfWood, int order, String customerName)
    {
        // initialise instance variables
        flatRate = 200;
        surface = length * width;
        numOfDrawers = numberOfDrawers;
        woodType = typeOfWood;
        orderNumber = order;
        name = customerName;
    }

    public int findWoodCharge()
    {
        if(woodType == 1){
            woodCharge = 150;
        } else if(woodType == 2) {
            woodCharge = 125;
        } else {
            woodCharge = 0;
        }
        
        return woodCharge;
    }
    
    /**
     * Calculate the charge for the number of drawers in the desk
     */
    public int getDrawerCharge()
    {
        drawerCharge = (numOfDrawers * 30);
        
        return drawerCharge;
    }
    
        /**
     * Calculate the total price of the desk
     */
    public void calculateTotal()
    {
            if(surface > 750) {
            total = total + 50;
        }
        
        total = total + (flatRate + drawerCharge + woodCharge);
        
    }
    
    /**
     * Print the details of the desk order
     * and the final price.
     */
    public void printOrder()
    {
           System.out.println("##################");
            System.out.println("Desk Order #: " + orderNumber);
            System.out.println("Customer Name: " + name);
            System.out.println("Desk surface area: " + surface + " Square inches");
            System.out.println("# of drawers: " + numOfDrawers + " Wood type: " + woodType);
            System.out.println("TOTAL PRICE = " + total);
            System.out.println("THANK YOU");
            System.out.println("##################");
            System.out.println(); 
    }
}
